from fastapi import FastAPI
from flowops_router import router as flowops_router

app = FastAPI()
app.include_router(flowops_router, prefix="/flowops")
