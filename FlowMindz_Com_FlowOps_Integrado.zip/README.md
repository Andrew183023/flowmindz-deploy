# FlowMindz Deploy

API com IA conectada ao FlowMindz e banco PostgreSQL (Railway).

## Endpoints
- POST `/analisar_oportunidade`

## Variáveis de ambiente
- DATABASE_URL
- OPENAI_API_KEY